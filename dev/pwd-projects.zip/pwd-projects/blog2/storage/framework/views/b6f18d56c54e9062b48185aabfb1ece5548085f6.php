<?php $__env->startSection("content"); ?>
    <div class="container">

        <?php if(session("info")): ?>
            <div class="alert alert-info">
                <?php echo e(session("info")); ?>

            </div>
        <?php endif; ?>

        <?php echo e($articles->links()); ?>


        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h3><?php echo e($article->title); ?></h3>
                    <small class="text-muted">
                        <b class="text-success">
                            <?php echo e($article->user->name); ?>

                        </b>
                        <?php echo e($article->created_at->diffForHumans()); ?>,
                        Category: <?php echo e($article->category->name); ?>,
                        <?php echo e(count($article->comments)); ?> Comments
                    </small>
                    <div><?php echo e($article->body); ?></div>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(url("/articles/detail/$article->id")); ?>" class="card-link">View Details...</a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eimg/Desktop/blog2/resources/views/articles/index.blade.php ENDPATH**/ ?>