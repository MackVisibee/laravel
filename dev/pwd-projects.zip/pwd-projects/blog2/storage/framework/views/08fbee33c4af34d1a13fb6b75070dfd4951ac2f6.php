<?php $__env->startSection("content"); ?>
    <div class="container">

        <?php if(session("info")): ?>
            <div class="alert alert-info">
                <?php echo e(session("info")); ?>

            </div>
        <?php endif; ?>

        <div class="card mb-3 border-1 border-primary">
            <div class="card-body">
                <h3><?php echo e($article->title); ?></h3>
                <small class="text-muted">
                    <b class="text-success">
                        <?php echo e($article->user->name); ?>

                    </b>
                    <?php echo e($article->created_at->diffForHumans()); ?>,
                    Category: <?php echo e($article->category->name); ?>

                </small>
                <div><?php echo e($article->body); ?></div>
            </div>
            <div class="card-footer">
                <?php if(auth()->guard()->check()): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("article-delete", $article)): ?>
                        <a href="<?php echo e(url("/articles/edit/$article->id")); ?>" class="btn btn-secondary">Edit</a>

                        <a href="<?php echo e(url("/articles/delete/$article->id")); ?>" class="btn btn-warning">Delete</a>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>

        <h4 class="ms-1 h5 mt-4">Comments (<?php echo e(count($article->comments)); ?>)</h4>
        <ul class="list-group">
            <?php $__currentLoopData = $article->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check("comment-delete", $comment)): ?>
                        <a href="<?php echo e(url("/comments/delete/$comment->id")); ?>"
                        class="btn-close float-end"></a>
                    <?php endif; ?>

                    <div>
                        <small>
                            <b class="text-success">
                                <?php echo e($comment->user->name); ?>

                            </b>
                            <?php echo e($comment->created_at->diffForHumans()); ?>

                        </small>
                    </div>

                    <?php echo e($comment->content); ?>

                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>

        <?php if(auth()->guard()->check()): ?>
            <form action="<?php echo e(url("/comments/add")); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="article_id" value="<?php echo e($article->id); ?>">
                <textarea name="content" class="form-control my-2"></textarea>
                <button class="btn btn-secondary">Add Comment</button>
            </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eimg/Desktop/blog2/resources/views/articles/detail.blade.php ENDPATH**/ ?>