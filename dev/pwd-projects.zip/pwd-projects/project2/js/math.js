// js/math.js

export const PI = 3.14;

export function add(a, b) {
	return a + b;
}

function sub(a, b) {
	return a - b;
}
